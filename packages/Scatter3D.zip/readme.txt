Scatter3D
------------------------------------------------------------------------
Show a 3D scatter chart and demonstrates various effects.

The sample creates point data set with many data series.  Various
features of a 3D scatter chart are shown by selecting attributes through
checkboxes, including axes, legend, droplines and depth cue.

Interactive mouse operations are demonstrated by pressing the left mouse
button on the plot cube and moving the mouse to change the view
rotations.
